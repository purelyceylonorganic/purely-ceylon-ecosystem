import { Router } from "express";

import authRoutes from "./auth.routes";
import cartRoutes from "./cart.routes";
import orderRoutes from "./order.routes";

const router = Router();

router.use("/auth", authRoutes);

router.use("/cart", cartRoutes);

router.use("/orders", orderRoutes);

export default router;